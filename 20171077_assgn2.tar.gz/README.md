# LinuxShell
1. make
2. ./shell

- All the code is in main.c file. Will make it modular in upcoming assignment.
